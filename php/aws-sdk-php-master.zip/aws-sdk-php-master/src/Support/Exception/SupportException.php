<?php
namespace Aws\Support\Exception;

use Aws\Exception\AwsException;

/**
 * AWS Support service exception.
 */
class SupportException extends AwsException {}
