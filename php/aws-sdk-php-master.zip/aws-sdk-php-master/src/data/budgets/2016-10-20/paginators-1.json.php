<?php
// This file was auto-generated from sdk-root/src/data/budgets/2016-10-20/paginators-1.json
return [ 'pagination' => [],];
